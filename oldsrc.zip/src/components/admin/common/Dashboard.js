import React, { useEffect } from 'react';
import { FaUsers, FaShoppingCart, FaDollarSign, FaComments } from 'react-icons/fa';

// Mock Data for Quick Stats
const stats = [
  { id: 1, icon: <FaUsers className="text-blue-500 text-3xl" />, label: 'Total Users', value: '1,250' },
  { id: 2, icon: <FaShoppingCart className="text-green-500 text-3xl" />, label: 'Total Orders', value: '5,460' },
  { id: 3, icon: <FaDollarSign className="text-yellow-500 text-3xl" />, label: 'Revenue', value: '$24,530' },
  { id: 4, icon: <FaComments className="text-purple-500 text-3xl" />, label: 'Feedback', value: '320' },
];

const Dashboard = () => {
  useEffect(() => {
    // Load the Google Charts library
    const script = document.createElement('script');
    script.src = 'https://www.gstatic.com/charts/loader.js';
    script.onload = () => {
      window.google.charts.load('current', { packages: ['corechart', 'bar'] });
      window.google.charts.setOnLoadCallback(drawChart);
    };
    document.body.appendChild(script);
  }, []);

  const drawChart = () => {
    drawSalesChart();
  };

  const drawSalesChart = () => {
    const data = window.google.visualization.arrayToDataTable([
      ['Month', 'Sales'],
      ['Jan', 5000],
      ['Feb', 7000],
      ['Mar', 8000],
      ['Apr', 12000],
      ['May', 9500],
      ['Jun', 14000],
    ]);

    const options = {
      title: 'Monthly Sales ($)',
      hAxis: { title: 'Month', titleTextStyle: { color: '#fff' } },
      vAxis: { title: 'Sales', titleTextStyle: { color: '#fff' } },
      backgroundColor: '#2d3748',
      legendTextStyle: { color: '#fff' },
      titleTextStyle: { color: '#fff' },
      hAxisTextStyle: { color: '#fff' },
      vAxisTextStyle: { color: '#fff' },
      chartArea: { width: '80%', height: '70%' },
    };

    const chart = new window.google.visualization.ColumnChart(document.getElementById('sales_chart'));
    chart.draw(data, options);
  };

  return (
    <div className="bg-gray-900 min-h-screen p-4 text-white">
      {/* <AdminHeader title="Dashboard" /> */}
      {/* Welcome Message */}
      <div className="text-center my-4">
        <h2 className="text-2xl font-bold">Welcome to the Admin Dashboard</h2>
        <p className="text-gray-400 text-sm">Monitor your site's performance and key metrics here.</p>
      </div>

      {/* Quick Stats Cards */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        {stats.map((stat) => (
          <div key={stat.id} className="bg-gray-800 p-4 rounded-lg shadow-md text-center">
            <div className="mb-2">{stat.icon}</div>
            <h3 className="text-lg font-semibold">{stat.label}</h3>
            <p className="text-xl font-bold">{stat.value}</p>
          </div>
        ))}
      </div>

      {/* Chart Section */}
      <div className="bg-gray-800 p-4 mt-6 rounded-lg shadow-md">
        <h3 className="text-lg font-semibold mb-3">Sales Overview</h3>
        <div id="sales_chart" style={{ width: '100%', height: '250px' }}></div>
      </div>
    </div>
  );
};

export default Dashboard;