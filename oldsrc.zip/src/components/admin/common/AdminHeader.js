import React from 'react';

const AdminHeader = ({ title }) => {
  return (
    <div className="bg-gray-800 text-white py-4">
      <div className="container mx-auto px-4">
        <h1 className="text-3xl font-bold">{title}</h1>
      </div>
    </div>
  );
};

export default AdminHeader;