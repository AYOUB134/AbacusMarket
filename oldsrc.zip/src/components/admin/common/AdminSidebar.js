import React from 'react';
import { Link, useLocation } from 'react-router-dom';
import { FaHome, FaUsers, FaChartBar, FaCog, FaSignOutAlt, FaEdit, FaPalette, FaBox } from 'react-icons/fa';

const AdminSidebar = () => {
  const location = useLocation();
  const menuItems = [
    { name: 'Dashboard', path: '/admin', icon: <FaHome /> },
    { name: 'Users', path: '/admin/users', icon: <FaUsers /> },
    { name: 'Reports', path: '/admin/reports', icon: <FaChartBar /> },
    { name: 'Settings', path: '/admin/settings', icon: <FaCog /> },
    { name: 'Site Management', path: '/admin/site-management', icon: <FaEdit /> },
    { name: 'Theme Management', path: '/admin/theme-management', icon: <FaPalette /> },
    { name: 'Product Listings', path: '/admin/product-listings', icon: <FaBox /> },
  ];

  return (
    <div className="w-full lg:w-1/5 bg-gray-800 text-white min-h-screen flex flex-col justify-between">
      <div>
        <div className="p-4 text-xl font-bold">Admin Panel</div>
        <nav className="mt-4">
          {menuItems.map((item) => (
            <Link
              key={item.name}
              to={item.path}
              className={`block py-2 px-4 rounded-md transition duration-200 hover:bg-gray-700 ${
                location.pathname === item.path ? 'bg-gray-700' : ''
              }`}
            >
              <div className="flex items-center">
                <span className="mr-3">{item.icon}</span>
                <span className="text-sm">{item.name}</span>
              </div>
            </Link>
          ))}
        </nav>
      </div>
      <div className="p-4">
        <Link
          to="/logout"
          className="block py-2 px-4 rounded-md transition duration-200 hover:bg-gray-700"
        >
          <div className="flex items-center">
            <FaSignOutAlt className="mr-3" />
            <span className="text-sm">Logout</span>
          </div>
        </Link>
      </div>
    </div>
  );
};

export default AdminSidebar;