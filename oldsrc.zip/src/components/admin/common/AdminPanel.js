import React from 'react';
import { Route, Routes } from 'react-router-dom';
import AdminSidebar from './AdminSidebar';
import AdminNavbar from './AdminNavbar';
import AdminFooter from './AdminFooter';
import Dashboard from './Dashboard';
import Users from './Users';
import Reports from './Reports';
import Settings from './Settings';
import SiteManagement from './SiteManagement';
import ThemeManagement from './ThemeManagement';
import ProductListings from './ProductListings';

const AdminPanel = () => {
  return (
    <div className="flex flex-col min-h-screen">
      <AdminNavbar />
      <div className="flex flex-grow">
        <AdminSidebar />
        <main className="flex-grow p-4">
          <Routes>
            {/* Ensure paths are relative to the base `/admin` path */}
            <Route path="/" element={<Dashboard />} />
            <Route path="users" element={<Users />} />
            <Route path="reports" element={<Reports />} />
            <Route path="settings" element={<Settings />} />
            <Route path="site-management" element={<SiteManagement />} />
            <Route path="theme-management" element={<ThemeManagement />} />
            <Route path="product-listings" element={<ProductListings />} />
          </Routes>
        </main>
      </div>
      <AdminFooter />
    </div>
  );
};

export default AdminPanel;