import React, { useState } from "react";

const ProductListings = () => {
  const [products, setProducts] = useState([]);
  const [newProduct, setNewProduct] = useState({
    name: "",
    price: "",
    vendor: "",
    rating: "",
    level: "",
    image: "",
    location: ""
  });

  const handleAddProduct = () => {
    if (!newProduct.name || !newProduct.price) return;
    setProducts([...products, { ...newProduct, id: Date.now() }]);
    setNewProduct({ name: "", price: "", vendor: "", rating: "", level: "", image: "", location: "" });
  };

  const handleDeleteProduct = (id) => {
    setProducts(products.filter((product) => product.id !== id));
  };

  const handleUpdateProduct = (id, field, value) => {
    setProducts(products.map((product) => 
      product.id === id ? { ...product, [field]: value } : product
    ));
  };

  return (
    <div className="bg-gray-900 min-h-screen p-4 text-white text-xs">
      <div className="max-w-4xl mx-auto bg-gray-800 p-4 rounded-lg shadow-md">
        <h2 className="text-lg font-semibold mb-4 text-center">Manage Products</h2>
        <div className="grid grid-cols-2 md:grid-cols-3 gap-2 mb-4">
          <input type="text" placeholder="Name" className="p-1 rounded-md text-black text-xs" value={newProduct.name} onChange={(e) => setNewProduct({ ...newProduct, name: e.target.value })} />
          <input type="number" placeholder="Price" className="p-1 rounded-md text-black text-xs" value={newProduct.price} onChange={(e) => setNewProduct({ ...newProduct, price: e.target.value })} />
          <input type="text" placeholder="Vendor" className="p-1 rounded-md text-black text-xs" value={newProduct.vendor} onChange={(e) => setNewProduct({ ...newProduct, vendor: e.target.value })} />
          <input type="text" placeholder="Rating" className="p-1 rounded-md text-black text-xs" value={newProduct.rating} onChange={(e) => setNewProduct({ ...newProduct, rating: e.target.value })} />
          <input type="text" placeholder="Level" className="p-1 rounded-md text-black text-xs" value={newProduct.level} onChange={(e) => setNewProduct({ ...newProduct, level: e.target.value })} />
          <input type="text" placeholder="Ships From" className="p-1 rounded-md text-black text-xs" value={newProduct.location} onChange={(e) => setNewProduct({ ...newProduct, location: e.target.value })} />
          <input type="text" placeholder="Image URL" className="p-1 rounded-md text-black text-xs" value={newProduct.image} onChange={(e) => setNewProduct({ ...newProduct, image: e.target.value })} />
        </div>
        <button className="bg-blue-500 text-white px-3 py-1 rounded-md text-xs" onClick={handleAddProduct}>Add Product</button>

        <table className="w-full border-collapse border border-gray-700 text-xs mt-4">
          <thead>
            <tr className="bg-gray-700 text-white">
              <th className="p-1 border">Image</th>
              <th className="p-1 border">Product Name</th>
              <th className="p-1 border">Price ($)</th>
              <th className="p-1 border">Vendor</th>
              <th className="p-1 border">Rating</th>
              <th className="p-1 border">Level</th>
              <th className="p-1 border">Ships From</th>
              <th className="p-1 border">Actions</th>
            </tr>
          </thead>
          <tbody>
            {products.map((product) => (
              <tr key={product.id} className="bg-gray-600 text-white">
                <td className="p-1 border"><img src={product.image} alt="Product" className="h-10 w-10 object-cover" /></td>
                <td className="p-1 border"><input type="text" className="bg-transparent w-full p-0.5 text-xs" value={product.name} onChange={(e) => handleUpdateProduct(product.id, "name", e.target.value)} /></td>
                <td className="p-1 border"><input type="number" className="bg-transparent w-full p-0.5 text-xs" value={product.price} onChange={(e) => handleUpdateProduct(product.id, "price", e.target.value)} /></td>
                <td className="p-1 border"><input type="text" className="bg-transparent w-full p-0.5 text-xs" value={product.vendor} onChange={(e) => handleUpdateProduct(product.id, "vendor", e.target.value)} /></td>
                <td className="p-1 border"><input type="text" className="bg-transparent w-full p-0.5 text-xs" value={product.rating} onChange={(e) => handleUpdateProduct(product.id, "rating", e.target.value)} /></td>
                <td className="p-1 border"><input type="text" className="bg-transparent w-full p-0.5 text-xs" value={product.level} onChange={(e) => handleUpdateProduct(product.id, "level", e.target.value)} /></td>
                <td className="p-1 border"><input type="text" className="bg-transparent w-full p-0.5 text-xs" value={product.location} onChange={(e) => handleUpdateProduct(product.id, "location", e.target.value)} /></td>
                <td className="p-1 border">
                  <button className="bg-red-500 text-white px-2 py-0.5 rounded-md text-xs" onClick={() => handleDeleteProduct(product.id)}>Delete</button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default ProductListings;