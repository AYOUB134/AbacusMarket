import React, { useState } from 'react';

const Settings = () => {
  const [emailNotifications, setEmailNotifications] = useState(true);
  const [twoFactorAuth, setTwoFactorAuth] = useState(false);
  const [siteMaintenance, setSiteMaintenance] = useState(false);
  const [darkMode, setDarkMode] = useState(true);
  const [language, setLanguage] = useState('English');
  const [autoUpdates, setAutoUpdates] = useState(true);
  const [backup, setBackup] = useState(false);

  return (
    <div className=" min-h-screen p-4 text-white text-xs">
      <div className="max-w-4xl mx-auto  p-4 rounded-lg shadow-md">
        <h2 className="text-lg font-semibold mb-4 text-center">Site Settings</h2>

        <div className="mb-3 flex items-center">
          <input
            type="checkbox"
            checked={emailNotifications}
            onChange={() => setEmailNotifications(!emailNotifications)}
            className="mr-2"
          />
          <label className="text-xs font-semibold">Email Notifications</label>
        </div>

        <div className="mb-3 flex items-center">
          <input
            type="checkbox"
            checked={twoFactorAuth}
            onChange={() => setTwoFactorAuth(!twoFactorAuth)}
            className="mr-2"
          />
          <label className="text-xs font-semibold">Two-Factor Authentication</label>
        </div>

        <div className="mb-3 flex items-center">
          <input
            type="checkbox"
            checked={siteMaintenance}
            onChange={() => setSiteMaintenance(!siteMaintenance)}
            className="mr-2"
          />
          <label className="text-xs font-semibold">Site Maintenance Mode</label>
        </div>

        <div className="mb-3 flex items-center">
          <input
            type="checkbox"
            checked={darkMode}
            onChange={() => setDarkMode(!darkMode)}
            className="mr-2"
          />
          <label className="text-xs font-semibold">Dark Mode</label>
        </div>

        <div className="mb-3">
          <label className="block text-xs font-semibold mb-1">Language</label>
          <select
            value={language}
            onChange={(e) => setLanguage(e.target.value)}
            className="w-full p-2 rounded-md text-black"
          >
            <option value="English">English</option>
            <option value="Spanish">Spanish</option>
            <option value="French">French</option>
            <option value="German">German</option>
            <option value="Chinese">Chinese</option>
          </select>
        </div>

        <div className="mb-3 flex items-center">
          <input
            type="checkbox"
            checked={autoUpdates}
            onChange={() => setAutoUpdates(!autoUpdates)}
            className="mr-2"
          />
          <label className="text-xs font-semibold">Enable Auto Updates</label>
        </div>

        <div className="mb-3 flex items-center">
          <input
            type="checkbox"
            checked={backup}
            onChange={() => setBackup(!backup)}
            className="mr-2"
          />
          <label className="text-xs font-semibold">Enable Automatic Backup</label>
        </div>

        <div className="mt-6">
          <button className="bg-blue-500 text-white px-4 py-2 rounded w-full text-xs">
            Save Changes
          </button>
        </div>
      </div>
    </div>
  );
};

export default Settings;