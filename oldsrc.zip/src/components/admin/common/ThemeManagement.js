import React, { useState } from "react";

const ThemeManagement = () => {
  const [theme, setTheme] = useState({
    primaryColor: "#0d1b2a",
    secondaryColor: "#1b263b",
    buttonColor: "#415a77",
    backgroundColor: "#778da9",
    textColor: "#e0e1dd",
  });

  const handleThemeChange = (e) => {
    setTheme({ ...theme, [e.target.name]: e.target.value });
  };

  return (
    <div className=" min-h-screen p-4 text-white text-xs">
      <div className="max-w-4xl mx-auto  p-4 rounded-lg shadow-md">
        <h2 className="text-lg font-semibold mb-4 text-center">Manage Theme</h2>
        <div className="grid grid-cols-2 gap-4 mb-4">
          {Object.keys(theme).map((key) => (
            <div key={key}>
              <label className="block text-xs font-semibold mb-1">
                {key.replace(/([A-Z])/g, " $1").replace(/^./, (str) => str.toUpperCase())}:
              </label>
              <input
                type="color"
                name={key}
                className="w-full p-1 rounded-md"
                value={theme[key]}
                onChange={handleThemeChange}
              />
              <input
                type="text"
                className="w-full p-1 mt-1 text-gray-900 text-xs rounded-md"
                value={theme[key]}
                readOnly
              />
            </div>
          ))}
        </div>
        <button className="bg-blue-500 text-white px-4 py-2 rounded w-full mt-4 text-xs">
          Save Theme
        </button>
      </div>
    </div>
  );
};

export default ThemeManagement;