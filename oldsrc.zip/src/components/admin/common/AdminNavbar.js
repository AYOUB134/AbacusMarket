import React from 'react';
import { FaBell, FaUserCircle } from 'react-icons/fa';

const AdminNavbar = () => {
  return (
    <div className="bg-gray-900 text-white py-3 fixed w-full z-10">
      <div className="container mx-auto px-4 flex justify-between items-center">
        <div className="text-xl font-bold">Admin Panel</div>
        <div className="flex items-center space-x-3">
          <FaBell className="w-5 h-5" />
          <FaUserCircle className="w-7 h-7" />
        </div>
      </div>
    </div>
  );
};

export default AdminNavbar;