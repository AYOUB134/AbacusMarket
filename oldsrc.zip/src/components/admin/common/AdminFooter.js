import React from 'react';

const AdminFooter = () => {
  return (
    <div className="bg-gray-900 text-white py-4">
      <div className="container mx-auto px-4 text-center">
        &copy; {new Date().getFullYear()} Admin Panel. All rights reserved.
      </div>
    </div>
  );
};

export default AdminFooter;