import React, { useEffect, useState } from 'react';
import { FaUsers, FaUserPlus } from 'react-icons/fa';

// Mock Data for Quick Stats
const stats = [
  { id: 1, icon: <FaUsers className="text-blue-500 text-3xl" />, label: 'Total Users', value: '1,250' },
  { id: 2, icon: <FaUserPlus className="text-green-500 text-3xl" />, label: 'New Users This Month', value: '50' },
];

const Users = () => {
  const [users, setUsers] = useState([
    { id: 1, name: 'John Doe', email: 'john.doe@example.com', role: 'Admin' },
    { id: 2, name: 'Jane Smith', email: 'jane.smith@example.com', role: 'User' },
    { id: 3, name: 'Mike Johnson', email: 'mike.johnson@example.com', role: 'Moderator' },
  ]);

  const [searchTerm, setSearchTerm] = useState('');
  const [newUser, setNewUser] = useState({ name: '', email: '', role: 'User', password: '' });
  const [error, setError] = useState('');
  const [showModal, setShowModal] = useState(false);

  useEffect(() => {
    // Load the Google Charts library
    const script = document.createElement('script');
    script.src = 'https://www.gstatic.com/charts/loader.js';
    script.onload = () => {
      window.google.charts.load('current', { packages: ['corechart', 'bar'] });
      window.google.charts.setOnLoadCallback(drawChart);
    };
    document.body.appendChild(script);
  }, []);

  const drawChart = () => {
    drawUserGrowthChart();
  };

  const drawUserGrowthChart = () => {
    const data = window.google.visualization.arrayToDataTable([
      ['Month', 'Users'],
      ['Jan', 200],
      ['Feb', 250],
      ['Mar', 300],
      ['Apr', 350],
      ['May', 400],
    ]);

    const options = {
      title: 'User Growth',
      hAxis: { title: 'Month', titleTextStyle: { color: '#fff' } },
      vAxis: { title: 'Users', titleTextStyle: { color: '#fff' } },
      backgroundColor: '#2d3748',
      legendTextStyle: { color: '#fff' },
      titleTextStyle: { color: '#fff' },
      hAxisTextStyle: { color: '#fff' },
      vAxisTextStyle: { color: '#fff' },
      chartArea: { width: '80%', height: '70%' },
    };

    const chart = new window.google.visualization.ColumnChart(document.getElementById('user_growth_chart'));
    chart.draw(data, options);
  };

  // Handle Input Changes for New User
  const handleChange = (e) => {
    setNewUser({ ...newUser, [e.target.name]: e.target.value });
  };

  // Add New User
  const addUser = () => {
    if (!newUser.name || !newUser.email || !newUser.password) {
      setError('All fields are required!');
      return;
    }
    setError('');

    const newUserData = {
      id: users.length + 1,
      name: newUser.name,
      email: newUser.email,
      role: newUser.role,
    };

    setUsers([...users, newUserData]);
    setNewUser({ name: '', email: '', role: 'User', password: '' });
    setShowModal(false); // Close the modal after adding the user
  };

  // Handle User Deletion
  const deleteUser = (id) => {
    setUsers(users.filter((user) => user.id !== id));
  };

  // Filter Users Based on Search
  const filteredUsers = users.filter((user) =>
    user.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    user.email.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="bg-gray-900 min-h-screen p-4 text-white text-sm">
      {/* <AdminHeader title="Users" /> */}
      
      {/* Welcome Message */}
      <div className="text-center my-4">
        <h2 className="text-2xl font-bold">User Management</h2>
        <p className="text-gray-400 text-sm">Manage and monitor your site's users here.</p>
      </div>

      {/* Quick Stats Cards */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        {stats.map((stat) => (
          <div key={stat.id} className="bg-gray-800 p-4 rounded-lg shadow-md text-center">
            <div className="mb-2">{stat.icon}</div>
            <h3 className="text-lg font-semibold">{stat.label}</h3>
            <p className="text-xl font-bold">{stat.value}</p>
          </div>
        ))}
      </div>

      {/* Chart Section */}
      <div className="bg-gray-800 p-4 mt-6 rounded-lg shadow-md">
        <h3 className="text-lg font-semibold mb-3">User Growth Overview</h3>
        <div id="user_growth_chart" style={{ width: '100%', height: '250px' }}></div>
      </div>

      {/* Search Bar and Add New User Button */}
      <div className="flex justify-between items-center mt-6">
        <input
          type="text"
          placeholder="Search by name or email..."
          className="w-full p-2 rounded-md text-black mb-3"
          onChange={(e) => setSearchTerm(e.target.value)}
        />
        <button
          className="bg-green-500 p-2 rounded-md text-xs ml-4"
          onClick={() => setShowModal(true)}
        >
          Add New User
        </button>
      </div>

      {/* User List */}
      <div className="bg-gray-800 p-4 rounded-lg shadow-md mt-6" style={{ width: '100%' }}>
        <ul className="space-y-2">
          {filteredUsers.length > 0 ? (
            filteredUsers.map((user) => (
              <li key={user.id} className="flex justify-between items-center p-2 bg-gray-700 rounded-md">
                <div>
                  <span className="font-bold">{user.name}</span> ({user.email}) - <span className="text-blue-300">{user.role}</span>
                </div>
                <button
                  className="bg-red-500 text-white px-2 py-1 rounded text-xs"
                  onClick={() => deleteUser(user.id)}
                >
                  Delete
                </button>
              </li>
            ))
          ) : (
            <p className="text-center text-gray-400">No users found.</p>
          )}
        </ul>
      </div>

      {/* Add New User Modal */}
      {showModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex justify-center items-center">
          <div className="bg-gray-800 p-4 rounded-lg shadow-md max-w-lg w-full">
            <h3 className="text-lg font-semibold mb-2 text-center">Add New User</h3>
            {error && <p className="text-red-400 text-xs">{error}</p>}
            
            <input
              type="text"
              name="name"
              placeholder="Full Name"
              className="w-full p-2 rounded-md text-black mb-2"
              value={newUser.name}
              onChange={handleChange}
            />
            <input
              type="email"
              name="email"
              placeholder="Email"
              className="w-full p-2 rounded-md text-black mb-2"
              value={newUser.email}
              onChange={handleChange}
            />
            <select
              name="role"
              className="w-full p-2 rounded-md text-black mb-2"
              value={newUser.role}
              onChange={handleChange}
            >
              <option value="User">User</option>
              <option value="Admin">Admin</option>
              <option value="Moderator">Moderator</option>
            </select>
            <input
              type="password"
              name="password"
              placeholder="Password"
              className="w-full p-2 rounded-md text-black mb-2"
              value={newUser.password}
              onChange={handleChange}
            />
            <div className="flex justify-end">
              <button
                className="bg-green-500 p-2 rounded-md text-xs"
                onClick={addUser}
              >
                Add User
              </button>
              <button
                className="bg-red-500 p-2 rounded-md text-xs ml-2"
                onClick={() => setShowModal(false)}
              >
                Cancel
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default Users;