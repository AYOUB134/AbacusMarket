import React, { useState } from "react";

const SiteManagement = () => {
  const [siteName, setSiteName] = useState("Abacus Market");
  const [logo, setLogo] = useState("");
  const [tagline, setTagline] = useState("The Best Market for You");
  const [contactEmail, setContactEmail] = useState("support@abacusmarket.com");
  const [footerText, setFooterText] = useState("© 2025 Abacus Market. All rights reserved.");

  const handleSiteNameChange = (e) => setSiteName(e.target.value);
  const handleLogoChange = (e) => {
    if (e.target.files[0]) {
      setLogo(URL.createObjectURL(e.target.files[0]));
    }
  };
  const handleTaglineChange = (e) => setTagline(e.target.value);
  const handleContactEmailChange = (e) => setContactEmail(e.target.value);
  const handleFooterTextChange = (e) => setFooterText(e.target.value);

  return (
    <div className=" min-h-screen p-4 text-white text-xs">
      <div className="max-w-4xl mx-auto  p-4 rounded-lg shadow-md">
        <h2 className="text-lg font-semibold mb-4 text-center">Manage Site Information</h2>
        <div className="mb-3">
          <label className="block text-xs font-semibold mb-1">Website Name:</label>
          <input
            type="text"
            className="w-full p-2 rounded-md text-gray-900 text-xs"
            value={siteName}
            onChange={handleSiteNameChange}
          />
        </div>
        <div className="mb-3">
          <label className="block text-xs font-semibold mb-1">Tagline:</label>
          <input
            type="text"
            className="w-full p-2 rounded-md text-gray-900 text-xs"
            value={tagline}
            onChange={handleTaglineChange}
          />
        </div>
        <div className="mb-3">
          <label className="block text-xs font-semibold mb-1">Logo:</label>
          <input
            type="file"
            className="w-full p-2 rounded-md text-gray-900 text-xs"
            onChange={handleLogoChange}
          />
        </div>
        {logo && (
          <div className="mt-4 flex justify-center">
            <img src={logo} alt="Logo" className="h-20 rounded-md shadow-md" />
          </div>
        )}
        <div className="mb-3 mt-4">
          <label className="block text-xs font-semibold mb-1">Contact Email:</label>
          <input
            type="email"
            className="w-full p-2 rounded-md text-gray-900 text-xs"
            value={contactEmail}
            onChange={handleContactEmailChange}
          />
        </div>
        <div className="mb-3">
          <label className="block text-xs font-semibold mb-1">Footer Text:</label>
          <input
            type="text"
            className="w-full p-2 rounded-md text-gray-900 text-xs"
            value={footerText}
            onChange={handleFooterTextChange}
          />
        </div>
        <div className="flex gap-2 mt-4">
          <button className="bg-blue-500 text-white px-4 py-2 rounded w-full text-xs">
            Save Changes
          </button>
          <button onClick={() => setLogo("")} className="bg-gray-600 text-white px-4 py-2 rounded w-full text-xs">
            Reset Logo
          </button>
        </div>
      </div>
    </div>
  );
};

export default SiteManagement;