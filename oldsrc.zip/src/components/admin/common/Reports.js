import React, { useEffect } from 'react';
import AdminHeader from './AdminHeader';

const Reports = () => {
  const reports = [
    { id: 1, title: 'Sales Report', date: '2025-02-25' },
    { id: 2, title: 'User Engagement Report', date: '2025-02-26' },
  ];

  useEffect(() => {
    // Load the Google Charts library
    const script = document.createElement('script');
    script.src = 'https://www.gstatic.com/charts/loader.js';
    script.onload = () => {
      window.google.charts.load('current', { packages: ['corechart', 'bar'] });
      window.google.charts.setOnLoadCallback(drawCharts);
    };
    document.body.appendChild(script);
  }, []);

  const drawCharts = () => {
    drawSalesChart();
    drawEngagementChart();
  };

  const drawSalesChart = () => {
    const data = window.google.visualization.arrayToDataTable([
      ['Month', 'Sales'],
      ['Jan', 4000],
      ['Feb', 3000],
      ['Mar', 5000],
      ['Apr', 4000],
      ['May', 6000],
    ]);

    const options = {
      title: 'Sales Data',
      hAxis: { title: 'Month', titleTextStyle: { color: '#fff' } },
      vAxis: { title: 'Sales', titleTextStyle: { color: '#fff' } },
      backgroundColor: '#2d3748',
      legendTextStyle: { color: '#fff' },
      titleTextStyle: { color: '#fff' },
      hAxisTextStyle: { color: '#fff' },
      vAxisTextStyle: { color: '#fff' },
      chartArea: { width: '80%', height: '70%' },
    };

    const chart = new window.google.visualization.LineChart(document.getElementById('sales_chart'));
    chart.draw(data, options);
  };

  const drawEngagementChart = () => {
    const data = window.google.visualization.arrayToDataTable([
      ['Month', 'Users'],
      ['Jan', 200],
      ['Feb', 150],
      ['Mar', 300],
      ['Apr', 250],
      ['May', 400],
    ]);

    const options = {
      title: 'User Engagement',
      hAxis: { title: 'Month', titleTextStyle: { color: '#fff' } },
      vAxis: { title: 'Users', titleTextStyle: { color: '#fff' } },
      backgroundColor: '#2d3748',
      legendTextStyle: { color: '#fff' },
      titleTextStyle: { color: '#fff' },
      hAxisTextStyle: { color: '#fff' },
      vAxisTextStyle: { color: '#fff' },
      chartArea: { width: '80%', height: '70%' },
    };

    const chart = new window.google.visualization.ColumnChart(document.getElementById('engagement_chart'));
    chart.draw(data, options);
  };

  return (
    <div className="bg-gray-900 min-h-screen p-4 text-white text-xs">
      {/* <AdminHeader title="Reports" /> */}
      <div className="max-w-4xl mx-auto bg-gray-800 p-4 rounded-lg shadow-md">
        <h2 className="text-lg font-semibold mb-2 text-center">Reports Overview</h2>
        <ul className="mt-4">
          {reports.map((report) => (
            <li key={report.id} className="p-2 border-b border-gray-700">
              {report.title} (Date: {report.date})
            </li>
          ))}
        </ul>

        <div className="mt-6">
          <h3 className="text-md font-semibold mb-2">Sales Data</h3>
          <div id="sales_chart" style={{ width: '100%', height: '250px' }}></div>
        </div>

        <div className="mt-6">
          <h3 className="text-md font-semibold mb-2">User Engagement</h3>
          <div id="engagement_chart" style={{ width: '100%', height: '250px' }}></div>
        </div>
      </div>
    </div>
  );
};

export default Reports;