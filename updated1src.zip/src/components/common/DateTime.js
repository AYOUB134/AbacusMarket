const DateTime = () => {
    return (
      <div className="text-sm text-gray-600">
        <span>20.02.2025 11:10 (UTC)</span>
      </div>
    )
  }
  
  export default DateTime